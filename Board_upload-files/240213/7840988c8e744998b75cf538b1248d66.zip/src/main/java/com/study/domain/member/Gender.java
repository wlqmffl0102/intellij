package com.study.domain.member;

public enum Gender {

    M, F

}